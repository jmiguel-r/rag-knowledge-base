"""
rag.py — RAG query engine with Ollama (100% local, zero cost)
Retrieves relevant context from ChromaDB and generates answers with a local LLM.
Usage: python rag.py
"""

from langchain_ollama import OllamaEmbeddings, ChatOllama
from langchain_chroma import Chroma
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

console = Console()

CHROMA_PATH = "./chroma_db"
COLLECTION  = "knowledge_base"
EMBED_MODEL = "nomic-embed-text"  # must match the model used in ingest.py
LLM_MODEL   = "llama3.2"          # local chat model

# ──────────────────────────────────────────
# System prompt — customize this for your use case
# ──────────────────────────────────────────
SYSTEM_PROMPT = """You are a knowledgeable assistant that answers questions based
ONLY on the provided context. If the information is not available in the context,
clearly state that you don't have that information in your knowledge base.

Retrieved context:
{context}

Answer clearly and accurately in the same language as the question.
"""

PROMPT_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    ("human", "{question}"),
])


def format_docs(docs: list) -> str:
    """Concatenate retrieved document chunks into a single context string."""
    return "\n\n---\n\n".join(
        f"[Source: {doc.metadata.get('source', 'unknown')}]\n{doc.page_content}"
        for doc in docs
    )


def build_rag_chain(k: int = 4):
    """Build and return the full RAG chain using LCEL (LangChain Expression Language)."""
    embeddings  = OllamaEmbeddings(model=EMBED_MODEL)
    vectorstore = Chroma(
        persist_directory=CHROMA_PATH,
        embedding_function=embeddings,
        collection_name=COLLECTION,
    )
    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": k},   # number of chunks to retrieve per query
    )
    llm = ChatOllama(model=LLM_MODEL, temperature=0)

    # LCEL chain: retrieve → format → prompt → LLM → parse
    chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | PROMPT_TEMPLATE
        | llm
        | StrOutputParser()
    )
    return chain, retriever


def query(question: str, chain, retriever) -> dict:
    """Run a RAG query and return the answer with its sources."""
    docs    = retriever.invoke(question)
    sources = list({doc.metadata.get("source", "—") for doc in docs})
    answer  = chain.invoke(question)
    return {"answer": answer, "sources": sources}


def interactive_chat():
    """Interactive terminal chat loop."""
    console.rule("[bold cyan]🤖 RAG Knowledge Base Assistant — Ollama (local)")
    console.print(f"[dim]LLM: {LLM_MODEL}  |  Embeddings: {EMBED_MODEL}[/dim]")
    console.print("[dim]Type your question or 'exit' to quit[/dim]\n")

    chain, retriever = build_rag_chain(k=4)

    while True:
        try:
            question = console.input("[bold green]You:[/bold green] ").strip()
        except (KeyboardInterrupt, EOFError):
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit", "q"):
            console.print("[dim]Goodbye![/dim]")
            break

        with console.status("[cyan]Searching knowledge base...[/cyan]"):
            result = query(question, chain, retriever)

        console.print(Panel(
            Markdown(result["answer"]),
            title="[bold blue]🤖 Assistant[/bold blue]",
            border_style="blue",
        ))
        console.print(f"[dim]📎 Sources: {', '.join(result['sources'])}[/dim]\n")


if __name__ == "__main__":
    interactive_chat()
